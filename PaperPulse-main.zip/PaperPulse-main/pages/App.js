import React from 'react';
import AxiomPulseDashboard from '../components/AxiomPulseDashboard';

export default function Home() {
  return (
    <div>
      <AxiomPulseDashboard />
    </div>
  );
}