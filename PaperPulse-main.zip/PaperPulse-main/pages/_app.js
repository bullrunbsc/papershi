import '../styles/axiom-pulse-styles.css'
import '../styles/axiom-token.css'

function MyApp({ Component, pageProps }) {
  return <Component {...pageProps} />
}

export default MyApp